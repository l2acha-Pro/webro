#!/data/data/com.termux/files/usr/bin/bash
set -e
proot-distro login ubuntu -- bash -c "
  cd ~ &&
  git clone --depth=1 https://github.com/rathena/rathena.git &&
  cd rathena &&
  mkdir build && cd build &&
  cmake .. &&
  make server
"
