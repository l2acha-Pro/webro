#!/data/data/com.termux/files/usr/bin/bash
set -e
proot-distro login ubuntu -- bash -c "
  service mysql start &&
  mysql -e "
    CREATE DATABASE IF NOT EXISTS rathena;
    CREATE USER IF NOT EXISTS 'ragnarok'@'localhost' IDENTIFIED BY 'password';
    GRANT ALL PRIVILEGES ON rathena.* TO 'ragnarok'@'localhost';
    FLUSH PRIVILEGES;"
  &&
  cd ~/rathena &&
  mysql -u ragnarok -ppassword rathena < sql-files/main.sql &&
  mysql -u ragnarok -ppassword rathena < sql-files/logs.sql
"
