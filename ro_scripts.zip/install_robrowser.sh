#!/data/data/com.termux/files/usr/bin/bash
set -e
proot-distro login ubuntu -- bash -c "
  cd /var/www/html &&
  git clone --depth=1 https://github.com/vthibault/roBrowser.git robrowser
"
