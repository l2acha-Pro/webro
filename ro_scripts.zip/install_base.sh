#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y && pkg upgrade -y
pkg install -y proot-distro git wget unzip screen
proot-distro install ubuntu || true
proot-distro login ubuntu -- bash -c "
  apt update -y && apt upgrade -y &&
  apt install -y build-essential cmake git mariadb-server libmariadb-dev nginx screen unzip
"
