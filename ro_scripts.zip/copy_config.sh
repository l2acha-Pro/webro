#!/data/data/com.termux/files/usr/bin/bash
set -e
termux_home=$HOME
proot_home=/root
cp "$termux_home/rathena_configs_pack.zip" "$PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/$proot_home/"
proot-distro login ubuntu -- bash -c "
  cd ~ &&
  unzip -o rathena_configs_pack.zip -d ~/rathena &&
  chmod +x ~/rathena/start_server.sh ~/rathena/stop_server.sh ~/rathena/auto_all.sh ~/rathena/auto_stop.sh || true
"
